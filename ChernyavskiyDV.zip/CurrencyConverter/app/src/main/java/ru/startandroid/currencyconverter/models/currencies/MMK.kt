package ru.startandroid.currencyconverter.models.currencies

data class MMK(
    val currencyName: String? = "",
    val id: String? = ""
)