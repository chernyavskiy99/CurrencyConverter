package ru.startandroid.currencyconverter.models.currencies

data class SZL(
    val currencyName: String? = "",
    val id: String? = ""
)