package ru.startandroid.currencyconverter.models.currencies

data class RSD(
    val currencyName: String? = "",
    val currencySymbol: String? = "",
    val id: String? = ""
)