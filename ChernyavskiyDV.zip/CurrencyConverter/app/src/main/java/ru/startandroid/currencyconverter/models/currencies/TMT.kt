package ru.startandroid.currencyconverter.models.currencies

data class TMT(
    val currencyName: String? = "",
    val id: String? = ""
)