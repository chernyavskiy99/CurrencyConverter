package ru.startandroid.currencyconverter.models.currencies

data class JOD(
    val currencyName: String? = "",
    val id: String? = ""
)