package ru.startandroid.currencyconverter.models.currencies

data class BND(
    val currencyName: String? = "",
    val currencySymbol: String? = "",
    val id: String? = ""
)