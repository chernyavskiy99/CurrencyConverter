package ru.startandroid.currencyconverter.models.currencies

data class AMD(
    val currencyName: String? = "",
    val id: String? = ""
)