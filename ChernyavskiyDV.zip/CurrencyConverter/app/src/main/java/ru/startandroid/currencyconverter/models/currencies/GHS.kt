package ru.startandroid.currencyconverter.models.currencies

data class GHS(
    val currencyName: String? = "",
    val id: String? = ""
)