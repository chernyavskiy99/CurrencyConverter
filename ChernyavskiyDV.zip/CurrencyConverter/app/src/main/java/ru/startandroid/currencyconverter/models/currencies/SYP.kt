package ru.startandroid.currencyconverter.models.currencies

data class SYP(
    val currencyName: String? = "",
    val currencySymbol: String? = "",
    val id: String? = ""
)