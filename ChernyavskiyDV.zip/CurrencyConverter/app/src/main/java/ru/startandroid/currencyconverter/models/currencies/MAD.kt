package ru.startandroid.currencyconverter.models.currencies

data class MAD(
    val currencyName: String? = "",
    val id: String? = ""
)