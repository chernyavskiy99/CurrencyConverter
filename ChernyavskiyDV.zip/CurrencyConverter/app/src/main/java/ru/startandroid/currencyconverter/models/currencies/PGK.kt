package ru.startandroid.currencyconverter.models.currencies

data class PGK(
    val currencyName: String? = "",
    val id: String? = ""
)