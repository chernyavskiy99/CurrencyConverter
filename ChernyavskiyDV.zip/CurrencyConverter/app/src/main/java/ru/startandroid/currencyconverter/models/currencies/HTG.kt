package ru.startandroid.currencyconverter.models.currencies

data class HTG(
    val currencyName: String? = "",
    val id: String? = ""
)