package ru.startandroid.currencyconverter.models.currencies

data class XOF(
    val currencyName: String? = "",
    val id: String? = ""
)