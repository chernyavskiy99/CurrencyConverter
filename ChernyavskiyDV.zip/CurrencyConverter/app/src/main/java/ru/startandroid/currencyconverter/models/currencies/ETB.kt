package ru.startandroid.currencyconverter.models.currencies

data class ETB(
    val currencyName: String? = "",
    val id: String? = ""
)