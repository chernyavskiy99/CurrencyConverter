package ru.startandroid.currencyconverter.models.currencies

data class LRD(
    val currencyName: String? = "",
    val currencySymbol: String? = "",
    val id: String? = ""
)