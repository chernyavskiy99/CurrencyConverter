package ru.startandroid.currencyconverter.models.currencies

data class DJF(
    val currencyName: String? = "",
    val id: String? = ""
)