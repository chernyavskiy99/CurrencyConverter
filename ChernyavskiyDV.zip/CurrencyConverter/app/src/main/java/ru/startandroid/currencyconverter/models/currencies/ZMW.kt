package ru.startandroid.currencyconverter.models.currencies

data class ZMW(
    val currencyName: String? = "",
    val id: String? = ""
)