package ru.startandroid.currencyconverter.models.currencies

data class TND(
    val currencyName: String? = "",
    val id: String? = ""
)