package ru.startandroid.currencyconverter.models.currencies

data class TOP(
    val currencyName: String? = "",
    val id: String? = ""
)