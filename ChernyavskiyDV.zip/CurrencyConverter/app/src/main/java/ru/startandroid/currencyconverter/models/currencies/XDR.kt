package ru.startandroid.currencyconverter.models.currencies

data class XDR(
    val currencyName: String? = "",
    val id: String? = ""
)