package ru.startandroid.currencyconverter.models.currencies

data class KMF(
    val currencyName: String? = "",
    val id: String? = ""
)