package ru.startandroid.currencyconverter.models.currencies

data class BDT(
    val currencyName: String? = "",
    val id: String? = ""
)