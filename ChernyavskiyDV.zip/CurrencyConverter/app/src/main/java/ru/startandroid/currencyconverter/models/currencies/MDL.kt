package ru.startandroid.currencyconverter.models.currencies

data class MDL(
    val currencyName: String? = "",
    val id: String? = ""
)