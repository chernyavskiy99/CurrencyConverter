package ru.startandroid.currencyconverter.models.currencies

data class RWF(
    val currencyName: String? = "",
    val id: String? = ""
)