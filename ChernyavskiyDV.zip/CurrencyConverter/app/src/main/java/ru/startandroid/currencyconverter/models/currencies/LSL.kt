package ru.startandroid.currencyconverter.models.currencies

data class LSL(
    val currencyName: String? = "",
    val id: String? = ""
)