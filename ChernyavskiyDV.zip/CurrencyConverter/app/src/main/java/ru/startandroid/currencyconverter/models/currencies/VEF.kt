package ru.startandroid.currencyconverter.models.currencies

data class VEF(
    val currencyName: String? = "",
    val id: String? = ""
)