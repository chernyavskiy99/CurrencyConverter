package ru.startandroid.currencyconverter.models.currencies

data class TJS(
    val currencyName: String? = "",
    val id: String? = ""
)