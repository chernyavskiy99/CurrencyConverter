package ru.startandroid.currencyconverter.models.currencies

data class MGA(
    val currencyName: String? = "",
    val id: String? = ""
)