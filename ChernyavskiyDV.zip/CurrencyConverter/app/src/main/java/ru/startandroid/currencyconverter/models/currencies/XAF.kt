package ru.startandroid.currencyconverter.models.currencies

data class XAF(
    val currencyName: String? = "",
    val id: String? = ""
)