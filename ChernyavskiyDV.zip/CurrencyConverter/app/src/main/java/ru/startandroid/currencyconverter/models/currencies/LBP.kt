package ru.startandroid.currencyconverter.models.currencies

data class LBP(
    val currencyName: String? = "",
    val currencySymbol: String? = "",
    val id: String? = ""
)