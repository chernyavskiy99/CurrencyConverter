package ru.startandroid.currencyconverter.models.currencies

data class MRO(
    val currencyName: String? = "",
    val id: String? = ""
)