package ru.startandroid.currencyconverter.models.currencies

data class BGN(
    val currencyName: String? = "",
    val currencySymbol: String? = "",
    val id: String? = ""
)