package ru.startandroid.currencyconverter.models.currencies

data class CDF(
    val currencyName: String? = "",
    val id: String? = ""
)