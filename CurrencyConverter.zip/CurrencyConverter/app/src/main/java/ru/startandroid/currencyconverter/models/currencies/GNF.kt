package ru.startandroid.currencyconverter.models.currencies

data class GNF(
    val currencyName: String? = "",
    val id: String? = ""
)