package ru.startandroid.currencyconverter.models.currencies

data class NGN(
    val currencyName: String? = "",
    val currencySymbol: String? = "",
    val id: String? = ""
)