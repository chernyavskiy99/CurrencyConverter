package ru.startandroid.currencyconverter.models.currencies

data class STD(
    val currencyName: String? = "",
    val id: String? = ""
)