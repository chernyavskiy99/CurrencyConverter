package ru.startandroid.currencyconverter.models.currencies

data class MVR(
    val currencyName: String? = "",
    val id: String? = ""
)