package ru.startandroid.currencyconverter.models.currencies

data class XPF(
    val currencyName: String? = "",
    val id: String? = ""
)