package ru.startandroid.currencyconverter.models.currencies

data class BIF(
    val currencyName: String? = "",
    val id: String? = ""
)