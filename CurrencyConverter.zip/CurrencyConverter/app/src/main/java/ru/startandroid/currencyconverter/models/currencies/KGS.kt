package ru.startandroid.currencyconverter.models.currencies

data class KGS(
    val currencyName: String? = "",
    val currencySymbol: String? = "",
    val id: String? = ""
)