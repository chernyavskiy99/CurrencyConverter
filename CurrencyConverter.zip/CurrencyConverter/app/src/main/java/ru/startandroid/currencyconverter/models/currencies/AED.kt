package ru.startandroid.currencyconverter.models.currencies

data class AED(
    val currencyName: String? = "",
    val id: String? = ""
)