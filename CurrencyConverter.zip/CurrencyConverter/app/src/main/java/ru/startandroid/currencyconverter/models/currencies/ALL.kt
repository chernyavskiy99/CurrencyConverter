package ru.startandroid.currencyconverter.models.currencies

data class ALL(
    val currencyName: String? = "",
    val currencySymbol: String? = "",
    val id: String? = ""
)