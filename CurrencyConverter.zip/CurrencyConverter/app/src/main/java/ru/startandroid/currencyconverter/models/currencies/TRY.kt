package ru.startandroid.currencyconverter.models.currencies

data class TRY(
    val currencyName: String? = "",
    val id: String? = ""
)