package ru.startandroid.currencyconverter.models.currencies

data class LYD(
    val currencyName: String? = "",
    val id: String? = ""
)