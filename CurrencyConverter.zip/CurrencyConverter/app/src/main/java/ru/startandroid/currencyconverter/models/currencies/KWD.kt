package ru.startandroid.currencyconverter.models.currencies

data class KWD(
    val currencyName: String? = "",
    val id: String? = ""
)