package ru.startandroid.currencyconverter.models.currencies

data class GBP(
    val currencyName: String? = "",
    val currencySymbol: String? = "",
    val id: String? = ""
)