package ru.startandroid.currencyconverter.models.currencies

data class SRD(
    val currencyName: String? = "",
    val currencySymbol: String? = "",
    val id: String? = ""
)