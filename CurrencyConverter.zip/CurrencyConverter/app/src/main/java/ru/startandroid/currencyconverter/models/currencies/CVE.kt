package ru.startandroid.currencyconverter.models.currencies

data class CVE(
    val currencyName: String? = "",
    val id: String? = ""
)