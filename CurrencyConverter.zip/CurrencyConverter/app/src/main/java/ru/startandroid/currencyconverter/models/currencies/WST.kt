package ru.startandroid.currencyconverter.models.currencies

data class WST(
    val currencyName: String? = "",
    val id: String? = ""
)