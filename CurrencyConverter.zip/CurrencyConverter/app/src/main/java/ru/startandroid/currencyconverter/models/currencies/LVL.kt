package ru.startandroid.currencyconverter.models.currencies

data class LVL(
    val currencyName: String? = "",
    val currencySymbol: String? = "",
    val id: String? = ""
)