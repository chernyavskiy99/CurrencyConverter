package ru.startandroid.currencyconverter.models.currencies

data class GMD(
    val currencyName: String? = "",
    val id: String? = ""
)