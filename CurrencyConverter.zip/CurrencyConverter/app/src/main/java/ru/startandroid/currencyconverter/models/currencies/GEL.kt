package ru.startandroid.currencyconverter.models.currencies

data class GEL(
    val currencyName: String? = "",
    val id: String? = ""
)