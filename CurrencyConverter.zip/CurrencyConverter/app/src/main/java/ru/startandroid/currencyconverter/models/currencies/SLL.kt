package ru.startandroid.currencyconverter.models.currencies

data class SLL(
    val currencyName: String? = "",
    val id: String? = ""
)